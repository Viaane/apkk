package com.example.hsmon

import android.app.Activity
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var tv: TextView
    private lateinit var sp: SharedPreferences
    @Volatile private var running = true
    private val ruled = HashSet<String>()
    private val last = HashMap<String, Long>()
    private var lastT = 0L

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        sp = getSharedPreferences("hs", 0)
        tv = TextView(this).apply {
            textSize = 13f; typeface = Typeface.MONOSPACE; setPadding(32, 16, 32, 32)
            text = "Meminta akses root..."
        }
        val reset = Button(this).apply {
            text = "Reset total pemakaian"
            setOnClickListener { sp.edit().clear().apply(); last.clear() }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(reset)
            addView(ScrollView(this@MainActivity).apply { addView(tv) })
        })
        Thread { loop() }.start()
    }

    override fun onDestroy() { running = false; super.onDestroy() }

    private fun su(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val o = p.inputStream.bufferedReader().readText()
        p.waitFor(); o
    } catch (e: Exception) { "" }

    private fun fmt(b: Long): String = when {
        b >= 1_073_741_824 -> "%.2f GB".format(b / 1_073_741_824.0)
        b >= 1_048_576 -> "%.1f MB".format(b / 1_048_576.0)
        else -> "%d KB".format(b / 1024)
    }

    private fun rate(b: Double): String =
        if (b >= 1_048_576) "%.1f MB/s".format(b / 1_048_576.0) else "%.0f KB/s".format(b / 1024.0)

    private fun loop() {
        su("iptables -N HSMON 2>/dev/null; iptables -C FORWARD -j HSMON 2>/dev/null || iptables -I FORWARD 1 -j HSMON")
        while (running) {
            val out = su("ip neigh; echo ===; iptables -nvxL HSMON").split("===")
            val devs = linkedMapOf<String, String>() // ip -> mac
            out[0].lines().forEach { l ->
                val t = l.trim().split(Regex("\\s+"))
                if (t.size > 4 && "lladdr" in t && !l.contains("FAILED")) {
                    val dev = t[t.indexOf("dev") + 1]
                    if (!dev.startsWith("rmnet") && !dev.startsWith("ccmni") && dev != "wlan0" && ":" !in t[0])
                        devs[t[0]] = t[t.indexOf("lladdr") + 1]
                }
            }
            val fresh = devs.keys.filter { ruled.add(it) }
            if (fresh.isNotEmpty()) {
                su(fresh.joinToString("; ") {
                    "iptables -C HSMON -s $it 2>/dev/null || iptables -A HSMON -s $it; " +
                    "iptables -C HSMON -d $it 2>/dev/null || iptables -A HSMON -d $it"
                })
            }
            val now = System.currentTimeMillis()
            val dt = if (lastT == 0L) 1.0 else maxOf((now - lastT) / 1000.0, 0.2)
            lastT = now

            val spD = HashMap<String, Double>(); val spU = HashMap<String, Double>()
            val ed = sp.edit()
            val macs = HashSet(sp.getStringSet("macs", emptySet()) ?: emptySet())
            devs.forEach { (ip, mac) -> macs.add(mac); ed.putString("ip_$mac", ip) }
            ed.putStringSet("macs", macs)

            (out.getOrElse(1) { "" }).lines().drop(2).forEach { l ->
                val t = l.trim().split(Regex("\\s+"))
                if (t.size < 4) return@forEach
                val bytes = t[1].toLongOrNull() ?: return@forEach
                val src = t[t.size - 2]; val dst = t[t.size - 1]
                val ip: String; val dir: String
                if (src in devs) { ip = src; dir = "u" } else if (dst in devs) { ip = dst; dir = "d" } else return@forEach
                val mac = devs[ip]!!
                val key = "$ip|$dir"
                val prev = last[key] ?: sp.getLong("c_$key", -1L).takeIf { it >= 0 }
                val delta = if (prev == null) 0L else if (bytes >= prev) bytes - prev else bytes
                last[key] = bytes
                ed.putLong("c_$key", bytes)
                if (delta > 0) ed.putLong("t${dir}_$mac", sp.getLong("t${dir}_$mac", 0L) + delta)
                val s = delta / dt
                if (dir == "d") spD[mac] = (spD[mac] ?: 0.0) + s else spU[mac] = (spU[mac] ?: 0.0) + s
            }
            ed.apply()

            val online = devs.values.toSet()
            val rows = macs.map { m ->
                Triple(m, sp.getLong("td_$m", 0L), sp.getLong("tu_$m", 0L))
            }.sortedByDescending { it.second + it.third }
            val sb = StringBuilder("Online: ${online.size}   |   Total semua: ${fmt(rows.sumOf { it.second + it.third })}\n\n")
            rows.forEach { (m, d, u) ->
                val on = m in online
                sb.append(if (on) "● " else "○ ").append(sp.getString("ip_$m", "?")).append("  ").append(m).append('\n')
                if (on) sb.append("  Speed  ↓ ${rate(spD[m] ?: 0.0)}  ↑ ${rate(spU[m] ?: 0.0)}\n")
                sb.append("  TOTAL  ${fmt(d + u)}  (↓ ${fmt(d)}  ↑ ${fmt(u)})\n\n")
            }
            if (rows.isEmpty()) sb.append("Belum ada perangkat / root ditolak.")
            runOnUiThread { tv.text = sb.toString() }
            Thread.sleep(1000)
        }
    }
}
