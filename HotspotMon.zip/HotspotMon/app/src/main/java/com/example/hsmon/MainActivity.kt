package com.example.hsmon

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var tv: TextView
    @Volatile private var running = true

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tv = TextView(this).apply {
            textSize = 13f; typeface = Typeface.MONOSPACE; setPadding(32, 32, 32, 32)
            text = "Meminta akses root..."
        }
        setContentView(ScrollView(this).apply { addView(tv) })
        Thread { loop() }.start()
    }

    override fun onDestroy() { running = false; super.onDestroy() }

    private fun su(cmd: String): String = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor(); out
    } catch (e: Exception) { "ERR:" + e.message }

    private fun fmt(b: Long): String = when {
        b > 1_073_741_824 -> "%.2f GB".format(b / 1_073_741_824.0)
        b > 1_048_576 -> "%.1f MB".format(b / 1_048_576.0)
        else -> "%d KB".format(b / 1024)
    }

    private fun loop() {
        // chain khusus penghitung, dipasang di depan FORWARD
        su("iptables -N HSMON 2>/dev/null; iptables -C FORWARD -j HSMON 2>/dev/null || iptables -I FORWARD 1 -j HSMON")
        while (running) {
            // 1) daftar perangkat hotspot
            val devs = linkedMapOf<String, String>() // ip -> mac
            su("ip neigh").lines().forEach { l ->
                val t = l.trim().split(Regex("\\s+"))
                if (t.size > 4 && "lladdr" in t && !l.contains("FAILED")) {
                    val dev = t[t.indexOf("dev") + 1]
                    if (!dev.startsWith("rmnet") && !dev.startsWith("ccmni") && dev != "wlan0" && ":" !in t[0])
                        devs[t[0]] = t[t.indexOf("lladdr") + 1]
                }
            }
            // 2) pasang aturan hitung per IP (sekali saja)
            if (devs.isNotEmpty()) {
                su(devs.keys.joinToString("; ") {
                    "iptables -C HSMON -s $it 2>/dev/null || iptables -A HSMON -s $it; " +
                    "iptables -C HSMON -d $it 2>/dev/null || iptables -A HSMON -d $it"
                })
            }
            // 3) baca byte counter
            val up = HashMap<String, Long>(); val down = HashMap<String, Long>()
            su("iptables -nvxL HSMON").lines().drop(2).forEach { l ->
                val t = l.trim().split(Regex("\\s+"))
                if (t.size >= 4) {
                    val bytes = t[1].toLongOrNull() ?: return@forEach
                    val src = t[t.size - 2]; val dst = t[t.size - 1]
                    if (src in devs) up[src] = bytes   // dikirim perangkat
                    if (dst in devs) down[dst] = bytes // diterima perangkat
                }
            }
            val sb = StringBuilder("Perangkat terhubung: ${devs.size}\n\n")
            devs.forEach { (ip, mac) ->
                sb.append("$ip\n$mac\n  ↓ ${fmt(down[ip] ?: 0)}   ↑ ${fmt(up[ip] ?: 0)}\n\n")
            }
            if (devs.isEmpty()) sb.append("Belum ada perangkat / root ditolak.")
            runOnUiThread { tv.text = sb.toString() }
            Thread.sleep(3000)
        }
    }
}
